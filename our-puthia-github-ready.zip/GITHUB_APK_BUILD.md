# আমাদের পুঠিয়া — GitHub APK Build

এই project-এ GitHub Actions workflow আছে।

GitHub-এ source files upload করার পর:
Actions → Build Android APK → Run workflow

Build সফল হলে Artifacts থেকে `our-puthia-debug-apk` download করুন।
